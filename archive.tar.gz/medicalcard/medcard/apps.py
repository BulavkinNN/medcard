from django.apps import AppConfig


class MedcardConfig(AppConfig):
    name = 'medcard'

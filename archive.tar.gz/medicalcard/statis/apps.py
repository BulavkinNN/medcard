from django.apps import AppConfig


class StatisConfig(AppConfig):
    name = 'statis'
